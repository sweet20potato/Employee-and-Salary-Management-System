﻿#ifndef ATTENDANCE_H
#define ATTENDANCE_H

#include <string>
using namespace std;
class Attendance
{
private:
	int personalLeave;
	int sickLeave;
	int lateDate;
public:
	Attendance();
	Attendance(int, int, int);

	void setPersonalLeave(int);
	void setSickLeave(int);
	void setLateHour(int);

	int getPersonalLeave() const;
	int getSickLeave() const;
	int getLateHour() const;

	string print() const;
	double getFinalSalary(double baseSalary) const;
};

#endif